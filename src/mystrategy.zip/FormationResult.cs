﻿using System.Collections.Generic;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class FormationResult
    {
        public MyFormation Formation { get; set; }
        public List<Action> ActionList { get; set; }
        public int GroupIndex { get; set; }
    }
}