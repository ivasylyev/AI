﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum ActionStatus
    {
        Undefined = 0,
        Pending = 1,
        Executing = 2,
        Finished = 3,
        Aborted = 4
    }
}