﻿namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public enum ActionPriority
    {
        Normal = 0,
        High =1,
        Urgent =2
    }
}