﻿using System.Collections.Generic;
using Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk
{
    public class EnemyFormation : Formation
    {
        public override void Update(IEnumerable<VehicleUpdate> updates = null)
        {
            base.Update(updates);
        }
    }
}